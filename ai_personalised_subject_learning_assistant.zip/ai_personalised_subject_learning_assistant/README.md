# AI Personalised Subject Learning Assistant

A local AI learning assistant for engineering students using:

- Python 3.11
- Streamlit
- Ollama
- ChromaDB
- RAG (Retrieval Augmented Generation)

## Features

1. Personal learner profile
2. AI subject tutor
3. Upload TXT/MD/PDF study material
4. ChromaDB semantic search
5. Personalised study plans
6. Adaptive MCQ generation
7. Progress storage
8. Fully local LLM workflow

## 1. Install Python

Use Python 3.11.

Check:

```bash
python --version
```

## 2. Create virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

## 3. Install packages

```bash
pip install -r requirements.txt
```

## 4. Install Ollama

Install Ollama for Windows from the official Ollama website.

Then download models:

```bash
ollama pull llama3.2:3b
ollama pull nomic-embed-text
```

Check:

```bash
ollama list
```

## 5. Run the application

```bash
streamlit run app.py
```

The browser will open the Streamlit application.

## Architecture

```text
                    ┌─────────────────────┐
                    │    Streamlit UI     │
                    └──────────┬──────────┘
                               │
                    ┌──────────▼──────────┐
                    │ Python Backend      │
                    │ Learning Services   │
                    └───────┬───────┬──────┘
                            │       │
                 ┌──────────▼─┐   ┌▼──────────────┐
                 │   Ollama    │   │   ChromaDB    │
                 │   LLM       │   │ Vector Store  │
                 └─────────────┘   └───────────────┘
                            ▲             ▲
                            │             │
                     AI generation    RAG retrieval
```

## Important

The first version deliberately avoids cloud APIs and API keys.
Everything runs locally through Ollama.

If `llama3.2:3b` is too heavy for your computer, change
`OLLAMA_MODEL` in `.env` or `backend/config.py` to a smaller model
available on your system.

from ollama import Client
from backend.config import OLLAMA_HOST, OLLAMA_EMBED_MODEL

class OllamaEmbeddings:
    def __init__(self):
        self.client = Client(host=OLLAMA_HOST)
        self.model = OLLAMA_EMBED_MODEL

    def embed(self, texts):
        response = self.client.embed(model=self.model, input=texts)
        return response["embeddings"]

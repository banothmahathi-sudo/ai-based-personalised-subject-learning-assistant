import json
import re

def _profile_text(profile):
    return f"""
Student: {profile.get('name', 'Student')}
Branch: {profile.get('branch', 'EEE')}
Year: {profile.get('year', '2nd Year')}
Level: {profile.get('level', 'Beginner')}
Learning style: {profile.get('learning_style', 'Simple explanation')}
Weak topics: {', '.join(profile.get('weak_topics', []))}
"""

def explain_topic(llm, question, profile, context=""):
    system = """
You are an AI personalised engineering tutor.
Teach accurately and at the student's level.
Use simple Telugu-English when the student asks that way.
Do not invent facts from the supplied notes.
If the retrieved notes do not contain the answer, clearly say that
you are answering from general knowledge.
For numerical problems, show formulas and steps.
For EEE questions, prefer exam-oriented explanations, labelled concepts,
small examples, and key points.
"""
    prompt = f"""
Learner profile:
{_profile_text(profile)}

Retrieved study material:
{context or 'No relevant material was found.'}

Student question:
{question}

Give a clear, personalised answer. Mention an important exam point at the end.
"""
    return llm.chat(system, prompt)

def build_study_plan(llm, profile, subject, hours):
    system = """
You are a personalised study-planning AI for engineering students.
Create realistic plans, not generic motivational text.
Prioritise weak areas and active recall.
Include topic, duration, activity, and expected outcome.
"""
    prompt = f"""
Student:
{_profile_text(profile)}

Subject: {subject}
Available time today: {hours} hours

Generate a practical plan in Markdown.
"""
    return llm.chat(system, prompt)

def generate_quiz(llm, profile, subject, difficulty, count, context):
    system = """
You create engineering quizzes.
Return only Markdown.
Create exactly the requested number of MCQs.
Each question must have A-D options.
After all questions, provide an Answer Key with one correct option per question.
Do not make up content that contradicts the supplied context.
"""
    prompt = f"""
Student:
{_profile_text(profile)}

Subject: {subject}
Difficulty: {difficulty}
Number of questions: {count}

Study context:
{context or 'Use reliable general knowledge.'}

Generate the quiz.
"""
    return llm.chat(system, prompt, temperature=0.5)

def evaluate_answer(llm, question, answer, context=""):
    system = """
You are an exam evaluator. Assess the student's answer fairly.
Return:
1. Correct/Partially correct/Incorrect
2. Short reason
3. Correct concept
4. One improvement tip
"""
    prompt = f"""
Context:
{context}

Question:
{question}

Student answer:
{answer}
"""
    return llm.chat(system, prompt)

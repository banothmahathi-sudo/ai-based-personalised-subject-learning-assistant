import json
from backend.config import PROFILE_FILE

DEFAULT_PROFILE = {
    "name": "Student",
    "branch": "EEE",
    "year": "2nd Year",
    "level": "Beginner",
    "learning_style": "Simple explanation",
    "weak_topics": [],
    "progress": {}
}

def load_profile():
    if PROFILE_FILE.exists():
        try:
            return {**DEFAULT_PROFILE, **json.loads(PROFILE_FILE.read_text())}
        except Exception:
            pass
    return DEFAULT_PROFILE.copy()

def save_profile(profile):
    PROFILE_FILE.parent.mkdir(parents=True, exist_ok=True)
    PROFILE_FILE.write_text(json.dumps(profile, indent=2), encoding="utf-8")

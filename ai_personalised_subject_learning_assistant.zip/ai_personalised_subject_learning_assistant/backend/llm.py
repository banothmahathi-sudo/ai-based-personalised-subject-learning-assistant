from ollama import Client
from backend.config import OLLAMA_HOST, OLLAMA_MODEL

class OllamaLLM:
    def __init__(self, host=OLLAMA_HOST, model=OLLAMA_MODEL):
        self.client = Client(host=host)
        self.model = model

    def chat(self, system: str, prompt: str, temperature: float = 0.3) -> str:
        response = self.client.chat(
            model=self.model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
            options={"temperature": temperature},
        )
        return response["message"]["content"].strip()

from pathlib import Path
import hashlib
import chromadb
from pypdf import PdfReader

from backend.config import CHROMA_DIR
from backend.embeddings import OllamaEmbeddings

class RAGStore:
    def __init__(self):
        CHROMA_DIR.mkdir(parents=True, exist_ok=True)
        self.client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        self.collection = self.client.get_or_create_collection(
            name="study_materials"
        )
        self.embedder = OllamaEmbeddings()

    def _read_file(self, path: Path) -> str:
        if path.suffix.lower() == ".pdf":
            reader = PdfReader(str(path))
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        return path.read_text(encoding="utf-8", errors="ignore")

    def _chunk(self, text, chunk_size=900, overlap=150):
        text = " ".join(text.split())
        chunks = []
        start = 0
        while start < len(text):
            end = start + chunk_size
            chunk = text[start:end]
            if chunk.strip():
                chunks.append(chunk)
            start += chunk_size - overlap
        return chunks

    def ingest_file(self, path: Path, subject: str):
        text = self._read_file(path)
        chunks = self._chunk(text)
        if not chunks:
            return 0

        embeddings = self.embedder.embed(chunks)
        ids = [
            hashlib.sha256(f"{path.name}:{i}:{chunk}".encode()).hexdigest()
            for i, chunk in enumerate(chunks)
        ]
        self.collection.upsert(
            ids=ids,
            documents=chunks,
            embeddings=embeddings,
            metadatas=[
                {"source": path.name, "subject": subject}
                for _ in chunks
            ],
        )
        return len(chunks)

    def search(self, query: str, k: int = 4):
        if self.collection.count() == 0:
            return []

        embedding = self.embedder.embed([query])[0]
        result = self.collection.query(
            query_embeddings=[embedding],
            n_results=min(k, self.collection.count()),
        )

        docs = result.get("documents", [[]])[0]
        metas = result.get("metadatas", [[]])[0]

        return [
            {"text": text, "subject": meta.get("subject", "Unknown")}
            for text, meta in zip(docs, metas)
        ]

import streamlit as st
from pathlib import Path
from backend.llm import OllamaLLM
from backend.rag import RAGStore
from backend.profile import load_profile, save_profile
from backend.learning import (
    build_study_plan, generate_quiz, evaluate_answer, explain_topic
)

st.set_page_config(
    page_title="AI Personalised Subject Learning Assistant",
    page_icon="🎓",
    layout="wide"
)

DATA_DIR = Path("data")
NOTES_DIR = DATA_DIR / "notes"
DATA_DIR.mkdir(exist_ok=True)
NOTES_DIR.mkdir(exist_ok=True)

@st.cache_resource
def get_services():
    llm = OllamaLLM()
    rag = RAGStore()
    return llm, rag

llm, rag = get_services()

if "profile" not in st.session_state:
    st.session_state.profile = load_profile()

profile = st.session_state.profile

st.title("🎓 AI Personalised Subject Learning Assistant")
st.caption("Local AI • Ollama • ChromaDB • Streamlit • Python 3.11")

with st.sidebar:
    st.header("👤 Learner Profile")
    profile["name"] = st.text_input("Name", profile.get("name", "Student"))
    profile["branch"] = st.text_input("Branch", profile.get("branch", "EEE"))
    profile["year"] = st.selectbox(
        "Year", ["1st Year", "2nd Year", "3rd Year", "4th Year"],
        index=["1st Year","2nd Year","3rd Year","4th Year"].index(
            profile.get("year", "2nd Year")
        )
    )
    profile["level"] = st.selectbox(
        "Current Level", ["Beginner", "Intermediate", "Advanced"],
        index=["Beginner","Intermediate","Advanced"].index(
            profile.get("level", "Beginner")
        )
    )
    profile["learning_style"] = st.selectbox(
        "Preferred Style",
        ["Simple explanation", "Examples + explanation", "Exam-oriented", "Deep technical"],
        index=[
            "Simple explanation", "Examples + explanation",
            "Exam-oriented", "Deep technical"
        ].index(profile.get("learning_style", "Simple explanation"))
    )
    profile["weak_topics"] = st.text_input(
        "Weak topics (comma separated)",
        ", ".join(profile.get("weak_topics", []))
    ).split(",")
    profile["weak_topics"] = [x.strip() for x in profile["weak_topics"] if x.strip()]

    if st.button("💾 Save Profile"):
        save_profile(profile)
        st.success("Profile saved.")

    st.divider()
    st.header("📚 Add Study Material")
    uploaded = st.file_uploader(
        "Upload TXT, MD or PDF notes",
        type=["txt", "md", "pdf"]
    )
    subject = st.text_input("Subject", "Electrical Machines")

    if uploaded and st.button("➕ Add to Knowledge Base"):
        target = NOTES_DIR / uploaded.name
        target.write_bytes(uploaded.getbuffer())
        try:
            count = rag.ingest_file(target, subject)
            st.success(f"Added {count} chunks to ChromaDB.")
        except Exception as e:
            st.error(f"Could not index file: {e}")

tab1, tab2, tab3, tab4 = st.tabs([
    "💬 AI Tutor", "🗓️ Study Plan", "📝 Adaptive Quiz", "📊 Progress"
])

with tab1:
    st.subheader("Ask your AI tutor")
    if "messages" not in st.session_state:
        st.session_state.messages = []

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    question = st.chat_input("Ask a subject question...")
    if question:
        st.session_state.messages.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)

        context_docs = rag.search(question, k=4)
        context = "\n\n".join(
            f"[{d['subject']}] {d['text']}" for d in context_docs
        )

        with st.chat_message("assistant"):
            answer = explain_topic(
                llm=llm,
                question=question,
                profile=profile,
                context=context
            )
            st.markdown(answer)

        st.session_state.messages.append({"role": "assistant", "content": answer})

with tab2:
    st.subheader("Personalised Study Plan")
    c1, c2 = st.columns(2)
    with c1:
        plan_subject = st.text_input("Subject for plan", "Electrical Machines")
    with c2:
        hours = st.slider("Study time today (hours)", 0.5, 6.0, 1.5, 0.5)

    if st.button("✨ Generate My Plan"):
        with st.spinner("Creating your personalised plan..."):
            plan = build_study_plan(llm, profile, plan_subject, hours)
        st.markdown(plan)

with tab3:
    st.subheader("Adaptive Quiz")
    quiz_subject = st.text_input("Quiz subject", "Electrical Machines")
    difficulty = st.select_slider(
        "Difficulty", options=["Easy", "Medium", "Hard"], value="Medium"
    )
    num_questions = st.slider("Questions", 1, 10, 5)

    if st.button("🎯 Generate Quiz"):
        docs = rag.search(quiz_subject, k=5)
        context = "\n\n".join(d["text"] for d in docs)
        st.session_state.quiz = generate_quiz(
            llm, profile, quiz_subject, difficulty, num_questions, context
        )

    if st.session_state.get("quiz"):
        st.markdown(st.session_state.quiz)

with tab4:
    st.subheader("Learning Progress")
    progress = profile.get("progress", {})
    if progress:
        for topic, value in progress.items():
            st.write(f"**{topic}** — {value}%")
            st.progress(min(max(int(value), 0), 100))
    else:
        st.info("No progress recorded yet. Quiz performance can be added here.")
